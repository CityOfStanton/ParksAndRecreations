<p align="center">
  <img src="../../../Assets/Images/Logos/Volleyball-1_1-Color-Transparent-Logo.png" alt="Softball Logo" width="300"/>
</p>

# Description

The logo has the standard Stanton Cty Park frame, consisting of the center banner, bottom arched text, and "Parks & Rec" in the southern hemisphere. This has the black/color bars in the southern hemisphere. This is a common element for the league logos. The unique aspect of the image is the volleyball scene taking place featuring a doubles match with the first player on the left setting the ball to the second player on the left, who is attempting to spike the ball. The first plater on the right is attempting to block the spike as the second player on the right is attempting a diving dig. There are two clouds above the players.

# Color Palette

* **Lettering**: `#FFFFFF`
* **Frame**: `#000000`
* **Inner Background** `#FFFF00`

# Rasterized Images

| Full Name      | Width | Height | Color         | Background Color | Purpose                    | Filename                                                                                                                                    |
| -------------- | ----- | ------ | ------------- | ---------------- | -------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| Volleyball | 1     | 1      | Black & White | Transparent      | Logo                       | [Volleyball-1_1-BW-Transparent-Logo.png](Rasterized/Volleyball-1_1-BW-Transparent-Logo.png)                                         |
| Volleyball | 1     | 1      | Color         | Black            | Logo                       | [Volleyball-1_1-Color-Black-Logo.png](Rasterized/Volleyball-1_1-Color-Black-Logo.png)                                               |
| Volleyball | 1     | 1      | Color         | Yellow              | Logo                       | [Volleyball-1_1-Color-Yellow-Logo.png](Rasterized/Volleyball-1_1-Color-Yellow-Logo.png)                                                   |
| Volleyball | 1     | 1      | Color         | Transparent      | Main Logo                  | [Volleyball-1_1-Color-Transparent-Logo.png](Rasterized/Volleyball-1_1-Color-Transparent-Logo.png)                                   |
| Volleyball | 16    | 9      | Color         | Black            | Logo                       | [Volleyball-16_9-Color-Black-Logo.png](Rasterized/Volleyball-16_9-Color-Black-Logo.png)                                             |
| Volleyball | 16    | 9      | Color         | Yellow              | Logo                       | [Volleyball-16_9-Color-Yellow-Logo.png](Rasterized/Volleyball-16_9-Color-Yellow-Logo.png)                                                 |

# Public Use

The use of this image is allowed as long as it meets one of the following criteria:
1. Usage explicitly condoned by the Stanton City Parks & Recreations board or Stanton city employee authorized to represent the Stanton City Park.
2. Usage promoting an event being held at the Stanton City Park that has been approved by the Stanton City Parks & Recreations board or Stanton city employee authorized to represent the Stanton City Park.